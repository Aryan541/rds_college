# WEB APPLICATION FOR BCA DEPARTMENT OF RDS COLLEGE
>
> * Web Application For BCA (Bachelor of Computer Application) of Ram Dayalu Singh Collge, Muzaffarpur (RDS)
> * See deployment: [Click here](https://rdsbca.pythonanywhere.com/)

## Developed For

* Students of BCA Department of RDS College
* Management of BCA Department of RDS College
* Teachers of BCA Department of RDS College

## Badges

[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fsurajgirioffl%2FPadrone&count_bg=%2379C83D&title_bg=%23555555&icon=github.svg&icon_color=%23E7E7E7&title=Views&edge_flat=false)](https://hits.seeyoufarm.com)
[![MIT License](https://img.shields.io/badge/License-MIT-green.svg)](https://choosealicense.com/licenses/mit/)

## Contributors

<a href="https://github.com/surajgirioffl/RDS-BCA-Department/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=surajgirioffl/RDS-BCA-Department" />
</a>

## Author

* [Suraj Kumar Giri](https://www.github.com/surajgirioffl)
